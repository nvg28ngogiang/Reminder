package android.criminalintent;

import android.os.Bundle;

import androidx.fragment.app.FragmentActivity;

public class CrimeActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crime);
    }
}